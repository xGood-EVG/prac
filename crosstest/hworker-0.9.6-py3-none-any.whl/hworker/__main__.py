#!/usr/bin/env python3
"""
Prepare environment for run command line
"""

from .control import cli


cli.shell()
